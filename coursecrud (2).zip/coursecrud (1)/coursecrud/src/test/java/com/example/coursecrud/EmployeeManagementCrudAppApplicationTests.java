package com.example.coursecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
