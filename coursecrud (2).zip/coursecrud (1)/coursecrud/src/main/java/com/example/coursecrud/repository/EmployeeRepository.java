package com.example.coursecrud.repository;

import com.example.coursecrud.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Basic CRUD operations automatically available:
    // save(), findById(), findAll(), deleteById(), etc.
}