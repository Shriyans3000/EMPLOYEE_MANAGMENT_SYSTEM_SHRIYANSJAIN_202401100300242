package com.example.coursecrud.controller;

import com.example.coursecrud.entity.Employee;
import com.example.coursecrud.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Display all employees - UI Page
    @GetMapping("/")
    public String getAllEmployees(Model model) {
        List<Employee> employees = employeeRepository.findAll();
        model.addAttribute("employees", employees);
        model.addAttribute("employee", new Employee()); // For form
        return "employees"; // This will return employees.html
    }

    // Save employee (POST request for form submission)
    @PostMapping("/")
    public String saveEmployee(@ModelAttribute Employee employee) {
        employeeRepository.save(employee);
        return "redirect:/employees/"; // Redirect to display all employees
    }

    // Show edit form
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        model.addAttribute("employee", employee);
        model.addAttribute("employees", employeeRepository.findAll());
        return "employees"; // Same template for add/edit
    }

    // Update employee
    @PostMapping("/update/{id}")
    public String updateEmployee(@PathVariable Long id, @ModelAttribute Employee employeeDetails) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        employee.setName(employeeDetails.getName());
        employee.setDepartment(employeeDetails.getDepartment());

        employeeRepository.save(employee);
        return "redirect:/employees/";
    }

    // Delete employee
    @GetMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        employeeRepository.deleteById(id);
        return "redirect:/employees/";
    }

    // REST API Endpoints for Postman testing

    // GET all employees (JSON)
    @GetMapping("/api")
    @ResponseBody
    public List<Employee> getAllEmployeesApi() {
        return employeeRepository.findAll();
    }

    // GET employee by ID (JSON)
    @GetMapping("/api/{id}")
    @ResponseBody
    public Employee getEmployeeById(@PathVariable Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    // POST create employee (JSON)
    @PostMapping("/api")
    @ResponseBody
    public Employee createEmployee(@RequestBody Employee employee) {
        return employeeRepository.save(employee);
    }

    // PUT update employee (JSON)
    @PutMapping("/api/{id}")
    @ResponseBody
    public Employee updateEmployeeApi(@PathVariable Long id, @RequestBody Employee employeeDetails) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        employee.setName(employeeDetails.getName());
        employee.setDepartment(employeeDetails.getDepartment());

        return employeeRepository.save(employee);
    }

    // DELETE employee (JSON)
    @DeleteMapping("/api/{id}")
    @ResponseBody
    public String deleteEmployeeApi(@PathVariable Long id) {
        employeeRepository.deleteById(id);
        return "Employee deleted successfully";
    }
}